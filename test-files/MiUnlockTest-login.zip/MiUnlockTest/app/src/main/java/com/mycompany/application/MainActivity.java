package com.mycompany.application;
 
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.io.File;
import java.io.FileWriter;

public class MainActivity extends Activity { 

	private WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		webview = findViewById(R.id.activitymainWebView1);
		webview.setWebViewClient(new MyWebViewClient());
		webview.loadUrl("https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi&json=false&passive=true&hidden=false&_snsDefault=facebook&checkSafePhone=true&_locale=en");
        webview.getSettings().setJavaScriptEnabled(true);
    }

	private class MyWebViewClient extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url); // load the url
			return true;
		}
		
		@Override
		public void onPageFinished(WebView view, String url){
			String cookies = CookieManager.getInstance().getCookie(url);
			
			if (cookies != null) {
			StringBuilder sb = new StringBuilder();
			 String[] cookiesSpl = cookies.split(";");
			 for (String ar1 : cookiesSpl){
			      if (sb.length() == 0) {
					  sb.append(ar1);
				  } else {
					  sb.append("\n\n");
					  sb.append(ar1);
				  }
			 }              
			
			
				File dir = new File(getExternalFilesDir(null), "cookies");
				if(!dir.exists()){
					dir.mkdir();
				}

				try {
					int n = 0;
					String fileName = "cookie" + n + ".txt";
					
					File gpxfile = new File(dir, fileName);
					if (gpxfile.exists()) {
						n++;
						fileName = "cookie" + n + ".txt";
						gpxfile = new File(dir, fileName);
					}
					
					FileWriter writer = new FileWriter(gpxfile);
					writer.append(sb.toString().trim());
					writer.flush();
					writer.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void onBackPressed() {
		if (webview.canGoBack())
			webview.goBack();
		else
			super.onBackPressed();
	}
} 
